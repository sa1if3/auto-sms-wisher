  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.2
    </div>
    <strong>Copyright &copy; <a href="https://techmion.com">Techmion Solutions India Pvt. Ltd.</a></strong> All rights
    reserved.
  </footer>