<?php
if (isset($_POST['name'])) {
$message = strip_tags($_POST['msg1']);
echo 'success';
}
?>